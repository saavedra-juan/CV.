# 💫 About Me:
Como un escritor de tecnología y programador altamente calificado, tengo una amplia experiencia en la creación de contenido técnico y en la resolución de problemas de programación complejos. Además, mi capacidad para comunicar de manera clara y concisa ideas técnicas complejas a audiencias no técnicas me convierte en un candidato ideal para cualquier proyecto que requiera una comunicación efectiva y una comprensión sólida de la tecnología. Mi experiencia trabajando de forma remota también demuestra mi capacidad para ser altamente productivo y colaborativo en un entorno virtual, lo que hace que sea una opción excelente para cualquier trabajo remoto.


## 🌐 Socials:
[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://linkedin.com/in/https://www.linkedin.com/in/juan-saavedra-3602a714a/) [![Twitter](https://img.shields.io/badge/Twitter-%231DA1F2.svg?logo=Twitter&logoColor=white)](https://twitter.com/https://twitter.com/trabadelsiglo21) 

# 💻 Tech Stack:
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white) ![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white) ![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB) ![Apache](https://img.shields.io/badge/apache-%23D42029.svg?style=for-the-badge&logo=apache&logoColor=white) ![MySQL](https://img.shields.io/badge/mysql-%2300f.svg?style=for-the-badge&logo=mysql&logoColor=white) ![LINUX](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)
# 📊 GitHub Stats:
![](https://github-readme-stats.vercel.app/api?username=juan_saavedra&theme=dark&hide_border=false&include_all_commits=true&count_private=false)<br/>
![](https://github-readme-streak-stats.herokuapp.com/?user=juan_saavedra&theme=dark&hide_border=false)<br/>
![](https://github-readme-stats.vercel.app/api/top-langs/?username=juan_saavedra&theme=dark&hide_border=false&include_all_commits=true&count_private=false&layout=compact)

## 🐦 Latest Tweet
[![](https://gtce.itsvg.in/api?username=https://twitter.com/trabadelsiglo21)](https://github.com/VishwaGauravIn/github-twitter-card-embed)

### ✍️ Random Dev Quote
![](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=radical)

### 🔝 Top Contributed Repo
![](https://github-contributor-stats.vercel.app/api?username=juan_saavedra&limit=5&theme=dark&combine_all_yearly_contributions=true)

### 😂 Random Dev Meme
<img src="https://rm.up.railway.app/" width="512px"/>

---
[![](https://visitcount.itsvg.in/api?id=juan_saavedra&icon=0&color=0)](https://visitcount.itsvg.in)

<!-- Proudly created with GPRM ( https://gprm.itsvg.in ) -->
